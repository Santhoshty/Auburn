//Santhosh Thundena
//simple.cpp
// Dr. Li provided a standard deviation code and factorial code to implement in Project 1

#include <iostream>
#include <cmath>

/*Process an array of dynamic numbers (less than 10)
CAlCULATE:
   1.) A factorial value based on how many positive numbers users want to input
   2.) value of standard deviation and prints out

*/

using namespace std;


//declare methods
float calculateSD(float data[], int n);
float factorial(int f);

int main()
   {
   
   // initialization
   int amount;
   float data[amount];
      
      cout << "Enter amount of dynamic numbers" << endl;
      
      // take in amount of data from a user.
      cin >> amount;
      
      // create an array and have the user fill in data.
      cout << "Enter " << amount << " numbers." << endl;
      
         for (int i = 0; i < amount; ++i) {
              cin >> data[i];
         }
         
         
      cout << "\nFactorial of " << amount << ": " << factorial(amount) << endl;  
      
      cout << endl << "Standard Deviation = " << calculateSD(data, amount);   
         
      return 0;     
         
              
      }
      
float factorial (int f) 
   {
      float factorial = 1;
      
      for(int j = 1; j <= f; ++j) {
         factorial = factorial * j;
      }
      
      return factorial;

   }
   
float calculateSD (float data[], int n)
   {
   
    float sum = 0.0, mean, standardDeviation = 0.0;

    int i;

    for(i = 0; i < n; ++i)
    {
        sum += data[i];
    }

    mean = sum/n;

    for(i = 0; i < n; ++i)
        standardDeviation += pow(data[i] - mean, 2);

    return sqrt(standardDeviation / n);
   
   
   } 